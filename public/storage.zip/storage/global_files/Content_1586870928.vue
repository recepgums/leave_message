<template>

</template>

<script>
    export default {
        name: "Content"
    }
</script>

<style scoped>

</style>
