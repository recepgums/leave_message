<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GuestRoomMessages extends Model
{
    protected $table="guest_room_messages";
}
