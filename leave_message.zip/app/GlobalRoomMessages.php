<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GlobalRoomMessages extends Model
{
    protected $table="global";

}
